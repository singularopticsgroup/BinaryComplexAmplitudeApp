classdef DMDBaseControl < handle
    %DMDBASECONTROL Summary of this class goes here
    %   Detailed explanation goes here
    
    properties (Access = private)
        deviceID
        DMDSize
    end

    properties (Access = private, Constant)
        LIB_NAME = 'alp';
    end

    properties (Access = public, Constant)
        CONST = getAllConstants();
    end
    
    methods (Access = public)
        function obj = DMDBaseControl(libName, hFileName, deviceNum)
            %DMDMANAGER Construct an instance of this class
            %   Detailed explanation goes here

            %Fill missing inputs with empty bracets and then assign default
            %values
            if nargin < 1; libName = []; end 
            if nargin < 2; hFileName = []; end
            if nargin < 3; deviceNum = []; end
            
            [libName, hFileName, deviceNum] = obj.completeInputsIfNeeded(libName, hFileName, deviceNum);

            obj.initiateDLL(libName, hFileName);
            obj.initateDevice(deviceNum);
        end

        function deviceID = devAlloc(obj, deviceNum)
            ulongPtr = libpointer('uint32Ptr', 0);
            deviceID = obj.callDLLFun('AlpDevAlloc', int32(deviceNum), int32(0), ulongPtr);
        end

        function value = devInquire(obj, paramID)
            longPtr = libpointer('int32Ptr', 0);

            [~, ~] = obj.callDLLFun('AlpDevInquire', obj.deviceID, int32(paramID), longPtr);
            value = longPtr.Value;
        end
        
        function seqTiming(obj, seqID, illuminateTime, picTimeMicroSec, synchDelay, synchPulseWidth, triggerInDelay)
            %picTimeMicroSec = (picTimeSec)*10^6;
            [~, ~] = obj.callDLLFun('AlpSeqTiming', obj.deviceID, int32(seqID), int32(illuminateTime),...
            int32(picTimeMicroSec), int32(synchDelay), int32(synchPulseWidth), int32(triggerInDelay));
        end

        function devFree(obj)
             obj.callDLLFun('AlpDevFree', obj.deviceID);
        end
        
        function devHalt(obj)
            obj.callDLLFun('AlpDevHalt', obj.deviceID);
        end

        function seqID = seqAlloc(obj, bitDepth, picNum)
            ulongPtr = libpointer('uint32Ptr', 0);
            [seqID, ~] = obj.callDLLFun('AlpSeqAlloc', obj.deviceID, int32(bitDepth), int32(picNum), ulongPtr);
        end

        function seqPut(obj, seqID, picOffset, array)
            UserArrayPtr = libpointer('uint8Ptr', array);
            numOfPic = round( length(array) / (obj.DMDSize(1)*obj.DMDSize(2)) );
            [~, ~] = obj.callDLLFun('AlpSeqPut', obj.deviceID, int32(seqID), int32(picOffset), uint32(numOfPic), UserArrayPtr);
        end
        
        function seqFree(obj, seqID)
            obj.callDLLFun('AlpSeqFree', obj.deviceID, int32(seqID));
        end

        function projStart(obj, seqID)
            obj.callDLLFun('AlpProjStart', obj.deviceID, int32(seqID));
        end

        function projStartCont(obj, seqID)
            obj.projStart(seqID);
            obj.callDLLFun('AlpProjStartCont', obj.deviceID, int32(seqID));
        end
        
        function projHalt(obj)
            obj.callDLLFun('AlpProjHalt', obj.deviceID);
        end

        function projWait(obj)
            obj.callDLLFun('AlpProjWait', obj.deviceID);
        end

        function devControl(obj, paramID, paramValue)
            obj.callDLLFun('AlpDevControl', obj.deviceID, int32(paramID), paramValue);
        end
        
        function seqControl(obj, seqID, paramID, paramValue)
            obj.callDLLFun('AlpSeqControl', obj.deviceID, int32(seqID), int32(paramID), int32(paramValue));
        end
    
        function value = seqInquire(obj)
            ulongPtr = libpointer('uint32Ptr', 0);
            [value, ~] = obj.callDLLFun('AlpSeqInquire', obj.deviceID, int32(seqID), int32(paramID), ulongPtr);
        end

        function setProjParam(obj, paramID, paramValue)
            obj.callDLLFun('AlpProjControl', obj.deviceID, int32(paramID), int32(paramValue));
        end

        function value = getProjParam(obj, paramID)
            ulongPtr = libpointer('uint32Ptr', 0);
            [value, ~] = obj.callDLLFun('AlpProjInquire', obj.deviceID, int32(seqID), int32(paramID), ulongPtr);
        
        end
        
        function deviceID = getDeviceID(obj)
            deviceID = obj.deviceID;
        end

    end

    methods (Access = private)
            
        function initiateDLL(obj, libName, hFileName)
            % Domyślne wartości, jeśli nie są dostarczone
            if nargin < 1; libName = 'alp4395.dll'; end
            if nargin < 2; hFileName = 'alp.h'; end
        
            % Sprawdź, czy biblioteka nie jest już załadowana
            if ~libisloaded(obj.LIB_NAME)
                % Załaduj bibliotekę, tylko jeśli nie jest już załadowana
                loadlibrary(libName, hFileName, 'alias', obj.LIB_NAME);
            end
        end

        function initateDevice(obj, deviceNum)

            obj.deviceID = obj.devAlloc(deviceNum);
            obj.DMDSize = obj.getDMDSize();

        end

        function [pointersValue, returnValue] = callDLLFun(obj, funName, varargin)

            returnValue = calllib(obj.LIB_NAME, funName, varargin{:});
            
            if ~isempty(returnValue)
                obj.checkReturnFlag(returnValue);
            end

            pointers = obj.getPointersFromCells(varargin);
            pointersValue = obj.getValuesFromPointer(pointers);

        end

        function DMD_size = getDMDSize(obj)
            ALP_DEV_DISPLAY_HEIGHT = obj.CONST.DeviceTypes.ALP_DEV_DISPLAY_WIDTH;
            ALP_DEV_DISPLAY_WIDTH = obj.CONST.DeviceTypes.ALP_DEV_DISPLAY_HEIGHT;

            DMD_height = obj.devInquire(ALP_DEV_DISPLAY_HEIGHT);
            DMD_width = obj.devInquire(ALP_DEV_DISPLAY_WIDTH);
            
            DMD_size = [DMD_width, DMD_height]; % [X,Y]
        end
        
        function checkReturnFlag(obj, flag)

            if flag
                functionName = obj.getCallingFunctionName();
                flagName = obj.getFlagName(flag);
                warning(['Błąd w funkcji: ', functionName, '. Wykryto flagę: ', flagName, '.']);
            end
        end

        function flagName = getFlagName(obj, flag)
            returnValues = obj.CONST.ReturnValues;
            fields = fieldnames(returnValues);
        
            for i = 1:numel(fields)
                if returnValues.(fields{i}) == flag
                    flagName = fields{i};
                    return;
                end
            end
        
            % Jeśli nie znaleziono pasującego pola
            error('Nie znaleziono pasującego pola dla wartości flagi.');
        end
        
        function cleanup(obj)
            % Destructor
            obj.devHalt();
            obj.devFree();
        end

    end

    methods (Access = private, Static)
        function callingFunctionName = getCallingFunctionName()
            % Pobiera nazwę funkcji, która wywołała bieżącą funkcję
            st = dbstack();
            callingFunctionName = st(4).name;
        end
    
        function arrayFinall = images2array(imagesCell)
            % Sprawdź, czy imageCellArray jest komórką
            if ~iscell(imagesCell)
                error('Input must be a cell array of images.');
            end
            
            % Sprawdź, czy wszystkie obrazy mają taką samą rozdzielczość
            imageSize = size(imagesCell{1});
            if any(cellfun(@(img) ~isequal(size(img), imageSize), imagesCell))
                error('All images must have the same resolution.');
            end
            
            % Prealokacja wektora na podstawie rozmiaru obrazu
            arrayFinall = zeros(length(imagesCell) * numel(imagesCell{1}), 1);
            
            % Iteracja przez komórki
            for i = 1:length(imagesCell)
                % Sprawdź, czy każda komórka zawiera obraz (macierz)
                if ~ismatrix(imagesCell{i})
                    error('Each cell must contain a 2D matrix representing an image.');
                end
                
                % Spłaszcz obraz i dodaj do wektora
                arrayFinall((i-1)*numel(imagesCell{1})+1:i*numel(imagesCell{1})) = imagesCell{i}(:);
            end
        end
        
        function pointers = getPointersFromCells(cells)
            outputMask = zeros(length(cells), 1);
            for ii = 1 : length(cells)
                outputMask(ii) = isa(cells{ii}, 'lib.pointer');
            end
            pointers = [cells{outputMask == 1}];
        end
        
        function value = getValuesFromPointer(pointer)
            if ~isempty(pointer)
                value = pointer.Value;
            else
                value = [];
            end
        end
 
    end

    methods (Access = protected, Static)
        function [libName, hFileName, deviceNum] = completeInputsIfNeeded(libName, hFileName, deviceNum)
            % Inicjalizacja zmiennych wejściowych
            
            % Nadaj domyślne nazwy, jeśli zmienne są puste
            if isempty(libName); libName = 'alp4395.dll'; end
            if isempty(hFileName); hFileName = 'alp.h'; end
            if isempty(deviceNum); deviceNum = 0; end

        end
    end

end


function constants = getAllConstants()
    % Return values
    constants.ReturnValues.ALP_OK = 0;
    constants.ReturnValues.ALP_NOT_ONLINE = 1001;
    constants.ReturnValues.ALP_NOT_IDLE = 1002;
    constants.ReturnValues.ALP_NOT_AVAILABLE = 1003;
    constants.ReturnValues.ALP_NOT_READY = 1004;
    constants.ReturnValues.ALP_PARM_INVALID = 1005;
    constants.ReturnValues.ALP_ADDR_INVALID = 1006;
    constants.ReturnValues.ALP_MEMORY_FULL = 1007;
    constants.ReturnValues.ALP_SEQ_IN_USE = 1008;
    constants.ReturnValues.ALP_HALTED = 1009;
    constants.ReturnValues.ALP_ERROR_INIT = 1010;
    constants.ReturnValues.ALP_ERROR_COMM = 1011;
    constants.ReturnValues.ALP_DEVICE_REMOVED = 1012;
    constants.ReturnValues.ALP_NOT_CONFIGURED = 1013;
    constants.ReturnValues.ALP_LOADER_VERSION = 1014;
    constants.ReturnValues.ALP_ERROR_POWER_DOWN = 1018;
    constants.ReturnValues.ALP_DRIVER_VERSION = 1019;
    constants.ReturnValues.ALP_SDRAM_INIT = 1020;

    % Device Inquire and Control Types
    constants.DeviceTypes.ALP_DEVICE_NUMBER = 2000;
    constants.DeviceTypes.ALP_VERSION = 2001;
    constants.DeviceTypes.ALP_AVAIL_MEMORY = 2003;
    constants.DeviceTypes.ALP_SYNCH_POLARITY = 2004;
    constants.DeviceTypes.ALP_LEVEL_HIGH = 2006;
    constants.DeviceTypes.ALP_LEVEL_LOW = 2007;
    constants.DeviceTypes.ALP_TRIGGER_EDGE = 2005;
    constants.DeviceTypes.ALP_EDGE_FALLING = 2008;
    constants.DeviceTypes.ALP_EDGE_RISING = 2009;
    constants.DeviceTypes.ALP_DEV_DMDTYPE = 2021;
    constants.DeviceTypes.ALP_DMDTYPE_XGA = 1;
    constants.DeviceTypes.ALP_DMDTYPE_1080P_095A = 3;
    constants.DeviceTypes.ALP_DMDTYPE_XGA_07A = 4;
    constants.DeviceTypes.ALP_DMDTYPE_XGA_055X = 6;
    constants.DeviceTypes.ALP_DMDTYPE_WUXGA_096A = 7;
    constants.DeviceTypes.ALP_DMDTYPE_WQXGA_400MHZ_090A = 8;
    constants.DeviceTypes.ALP_DMDTYPE_WQXGA_480MHZ_090A = 9;
    constants.DeviceTypes.ALP_DMDTYPE_1080P_065A = 10;
    constants.DeviceTypes.ALP_DMDTYPE_1080P_065_S600 = 11;
    constants.DeviceTypes.ALP_DMDTYPE_WXGA_S450 = 12;
    constants.DeviceTypes.ALP_DMDTYPE_DLPC910REV = 254;
    constants.DeviceTypes.ALP_DMDTYPE_DISCONNECT = 255;
    constants.DeviceTypes.ALP_USB_CONNECTION = 2016;
    constants.DeviceTypes.ALP_DEV_DYN_SYNCH_OUT1_GATE = 2023;
    constants.DeviceTypes.ALP_DEV_DYN_SYNCH_OUT2_GATE = 2024;
    constants.DeviceTypes.ALP_DEV_DYN_SYNCH_OUT3_GATE = 2025;
    constants.DeviceTypes.ALP_DDC_FPGA_TEMPERATURE = 2050;
    constants.DeviceTypes.ALP_APPS_FPGA_TEMPERATURE = 2051;
    constants.DeviceTypes.ALP_PCB_TEMPERATURE = 2052;
    constants.DeviceTypes.ALP_DEV_DISPLAY_HEIGHT = 2057;
    constants.DeviceTypes.ALP_DEV_DISPLAY_WIDTH = 2058;
    constants.DeviceTypes.ALP_SEQ_DMD_LINES = 2125;
    constants.DeviceTypes.ALP_PWM_LEVEL = 2063;
    constants.DeviceTypes.ALP_DEV_DMD_MODE = 2064;
    constants.DeviceTypes.ALP_DMD_RESUME = 0;
    constants.DeviceTypes.ALP_DMD_POWER_FLOAT = 1;
    constants.DeviceTypes.ALP_USB_DISCONNECT_BEHAVIOUR = 2078;
    constants.DeviceTypes.ALP_USB_IGNORE = 1;
    constants.DeviceTypes.ALP_USB_RESET = 2;

    % Sequence Inquire and Control Types
    constants.SequenceTypes.ALP_BITPLANES = 2200;
    constants.SequenceTypes.ALP_BITNUM = 2103;
    constants.SequenceTypes.ALP_BIN_MODE = 2104;
    constants.SequenceTypes.ALP_BIN_NORMAL = 2105;
    constants.SequenceTypes.ALP_BIN_UNINTERRUPTED = 2106;
    constants.SequenceTypes.ALP_PICNUM = 2201;
    constants.SequenceTypes.ALP_FIRSTFRAME = 2101;
    constants.SequenceTypes.ALP_LASTFRAME = 2102;
    constants.SequenceTypes.ALP_FIRSTLINE = 2111;
    constants.SequenceTypes.ALP_LASTLINE = 2112;
    constants.SequenceTypes.ALP_LINE_INC = 2113;
    constants.SequenceTypes.ALP_SCROLL_FROM_ROW = 2123;
    constants.SequenceTypes.ALP_SCROLL_TO_ROW = 2124;
    constants.SequenceTypes.ALP_SEQ_REPEAT = 2100;
    constants.SequenceTypes.ALP_PICTURE_TIME = 2203;
    constants.SequenceTypes.ALP_MIN_PICTURE_TIME = 2211;
    constants.SequenceTypes.ALP_MAX_PICTURE_TIME = 2213;
    constants.SequenceTypes.ALP_ILLUMINATE_TIME = 2204;
    constants.SequenceTypes.ALP_MIN_ILLUMINATE_TIME = 2212;
    constants.SequenceTypes.ALP_ON_TIME = 2214;
    constants.SequenceTypes.ALP_OFF_TIME = 2215;
    constants.SequenceTypes.ALP_SYNCH_DELAY = 2205;
    constants.SequenceTypes.ALP_MAX_SYNCH_DELAY = 2209;
    constants.SequenceTypes.ALP_SYNCH_PULSEWIDTH = 2206;
    constants.SequenceTypes.ALP_TRIGGER_IN_DELAY = 2207;
    constants.SequenceTypes.ALP_MAX_TRIGGER_IN_DELAY = 2210;
    constants.SequenceTypes.ALP_DATA_FORMAT = 2110;
    constants.SequenceTypes.ALP_DATA_MSB_ALIGN = 0;
    constants.SequenceTypes.ALP_DATA_LSB_ALIGN = 1;
    constants.SequenceTypes.ALP_DATA_BINARY_TOPDOWN = 2;
    constants.SequenceTypes.ALP_DATA_BINARY_BOTTOMUP = 3;
    constants.SequenceTypes.ALP_SEQ_PUT_LOCK = 2119;
    constants.SequenceTypes.ALP_FLUT_MODE = 2118;
    constants.SequenceTypes.ALP_FLUT_NONE = 0;
    constants.SequenceTypes.ALP_FLUT_9BIT = 1;
    constants.SequenceTypes.ALP_FLUT_18BIT = 2;
    constants.SequenceTypes.ALP_FLUT_ENTRIES9 = 2120;
    constants.SequenceTypes.ALP_FLUT_OFFSET9 = 2122;
    constants.SequenceTypes.ALP_PWM_MODE = 2107;
    constants.SequenceTypes.ALP_FLEX_PWM = 3;
    constants.SequenceTypes.ALP_DMD_MASK_SELECT = 2134;
    constants.SequenceTypes.ALP_DMD_MASK_16X16 = 1;
    constants.SequenceTypes.ALP_DMD_MASK_16X8 = 2;
    constants.SequenceTypes.ALP_SEQ_DMD_LINES = 2125;

    % Projection Inquire and Control Types
    constants.ProjectionTypes.ALP_PROJ_MODE = 2300;
    constants.ProjectionTypes.ALP_MASTER = 2301;
    constants.ProjectionTypes.ALP_SLAVE = 2302;
    constants.ProjectionTypes.ALP_PROJ_STEP = 2329;
    constants.ProjectionTypes.ALP_PROJ_STATE = 2400;
    constants.ProjectionTypes.ALP_PROJ_ACTIVE = 1200;
    constants.ProjectionTypes.ALP_PROJ_IDLE = 1201;
    constants.ProjectionTypes.ALP_PROJ_INVERSION = 2306;
    constants.ProjectionTypes.ALP_PROJ_UPSIDE_DOWN = 2307;
    constants.ProjectionTypes.ALP_PROJ_QUEUE_MODE = 2314;
    constants.ProjectionTypes.ALP_PROJ_LEGACY = 0;
    constants.ProjectionTypes.ALP_PROJ_SEQUENCE_QUEUE = 1;
    constants.ProjectionTypes.ALP_PROJ_QUEUE_ID = 2315;
    constants.ProjectionTypes.ALP_PROJ_QUEUE_MAX_AVAIL = 2316;
    constants.ProjectionTypes.ALP_PROJ_QUEUE_AVAIL = 2317;
    constants.ProjectionTypes.ALP_PROJ_PROGRESS = 2318;
    constants.ProjectionTypes.ALP_FLAG_QUEUE_IDLE = 1;
    constants.ProjectionTypes.ALP_FLAG_SEQUENCE_ABORTING = 2;
    constants.ProjectionTypes.ALP_FLAG_SEQUENCE_INDEFINITE = 4;
    constants.ProjectionTypes.ALP_FLAG_FRAME_FINISHED = 8;
    constants.ProjectionTypes.ALP_PROJ_RESET_QUEUE = 2319;
    constants.ProjectionTypes.ALP_PROJ_ABORT_SEQUENCE = 2320;
    constants.ProjectionTypes.ALP_PROJ_ABORT_FRAME = 2321;
    constants.ProjectionTypes.ALP_PROJ_WAIT_UNTIL = 2323;
    constants.ProjectionTypes.ALP_PROJ_WAIT_PIC_TIME = 0;
    constants.ProjectionTypes.ALP_PROJ_WAIT_ILLU_TIME = 1;
    constants.ProjectionTypes.ALP_FLUT_MAX_ENTRIES9 = 2324;
    constants.ProjectionTypes.ALP_FLUT_WRITE_9BIT = 2325;
    constants.ProjectionTypes.ALP_FLUT_WRITE_18BIT = 2326;
    constants.ProjectionTypes.ALP_DMD_MASK_WRITE = 2339;

    % AlpSeqPutEx TransferModes
    constants.AlpSeqPutExTransferModes.ALP_PUT_LINES = 1;

    % LED Types
    constants.LedTypes.ALP_HLD_PT120_RAX = 268;
    constants.LedTypes.ALP_HLD_PT120_RED = 257;
    constants.LedTypes.ALP_HLD_PT120_GREEN = 258;
    constants.LedTypes.ALP_HLD_PT120TE_BLUE = 263;
    constants.LedTypes.ALP_HLD_PT120_BLUE = 259;
    constants.LedTypes.ALP_HLD_CBT90_UV = 265;
    constants.LedTypes.ALP_HLD_CBM120_UV365 = 266;
    constants.LedTypes.ALP_HLD_CBM120_UV = 267;
    constants.LedTypes.ALP_HLD_CBT120_UV = 260;
    constants.LedTypes.ALP_HLD_CBT90_WHITE = 262;
    constants.LedTypes.ALP_HLD_CBT140_WHITE = 264;

    % LED Inquire and Control Types
    constants.LedInquiry.ALP_LED_SET_CURRENT = 1001;
    constants.LedInquiry.ALP_LED_BRIGHTNESS = 1002;
    constants.LedInquiry.ALP_LED_FORCE_OFF = 1003;
    constants.LedInquiry.ALP_LED_AUTO_OFF = 0;
    constants.LedInquiry.ALP_LED_OFF = 1;
    constants.LedInquiry.ALP_LED_ON = 2;
    constants.LedInquiry.ALP_LED_TYPE = 1101;
    constants.LedInquiry.ALP_LED_MEASURED_CURRENT = 1102;
    constants.LedInquiry.ALP_LED_TEMPERATURE_REF = 1103;
    constants.LedInquiry.ALP_LED_TEMPERATURE_JUNCTION = 1104;

    % Extended LED Inquire and Control Types
    constants.LedExtendedInquiry.ALP_LED_ALLOC_PARAMS = 2101;
end
