classdef DMDProjInterface < handle
    %DMDPROJINTERFACE Summary of this class goes here
    %   Detailed explanation goes here
    
    properties (Access = private)
        DMDControler
        picTimeSec
        seqID
    end
    
    methods (Access = public)
        function obj = DMDProjInterface(libName, hFileName, deviceNum)
            %DMDPROJINTERFACE Construct an instance of this class
            %   Detailed explanation goes here

            if nargin < 1; libName = []; end 
            if nargin < 2; hFileName = []; end
            if nargin < 3; deviceNum = []; end

            obj.DMDControler = DMDBaseControl(libName, hFileName, deviceNum);
            obj.picTimeSec = 0.1;
        end
        
        function sizeDevice = getSize(obj)
                YSizeID = obj.DMDControler.CONST.DeviceTypes.ALP_DEV_DISPLAY_HEIGHT;
                XSizeID = obj.DMDControler.CONST.DeviceTypes.ALP_DEV_DISPLAY_WIDTH;
                YSize = obj.DMDControler.devInquire(YSizeID);
                XSize = obj.DMDControler.devInquire(XSizeID);

                sizeDevice = [XSize, YSize];
        end

        function seqHalt(obj)
            obj.DMDControler.projHalt();
            obj.DMDControler.seqFree(obj.seqID);
            obj.seqID = [];
        end

        function deviceFree(obj)
            obj.DMDControler.devFree();
        end
        
        function dispImages(obj, imageCells) 

            obj.seqID = obj.DMDControler.seqAlloc(1, length(imageCells));
            obj.DMDControler.seqTiming(obj.seqID, 0, obj.picTimeSec * 10^6, 0, 0, 0);
            
            array = obj.images2array(imageCells);
            obj.DMDControler.seqPut(obj.seqID, 0, array);

            obj.DMDControler.projStart(obj.seqID);
            obj.DMDControler.projStartCont(obj.seqID);
        end
        
        function setPicTime(obj, picTimeSec)
            obj.picTimeSec = picTimeSec;
        end
        
        function delete(obj)
            % Destruktor wywołujący deviceFree
            if ~isempty(obj.seqID)
                obj.seqHalt();
            end
            obj.deviceFree();
        end

    end

    methods (Access = private, Static)
        function arrayFinall = images2array(imagesCell)
            % Sprawdź, czy imageCellArray jest komórką
            if ~iscell(imagesCell)
                error('Input must be a cell array of images.');
            end
            
            % Sprawdź, czy wszystkie obrazy mają taką samą rozdzielczość
            imageSize = size(imagesCell{1});
            if any(cellfun(@(img) ~isequal(size(img), imageSize), imagesCell))
                error('All images must have the same resolution.');
            end
            
            % Prealokacja wektora na podstawie rozmiaru obrazu
            arrayFinall = zeros(length(imagesCell) * numel(imagesCell{1}), 1);
            
            % Iteracja przez komórki
            for i = 1:length(imagesCell)
                % Sprawdź, czy każda komórka zawiera obraz (macierz)
                if ~ismatrix(imagesCell{i})
                    error('Each cell must contain a 2D matrix representing an image.');
                end
                
                % Spłaszcz obraz i dodaj do wektora
                arrayFinall((i-1)*numel(imagesCell{1})+1:i*numel(imagesCell{1})) = imagesCell{i}(:);
            end
        end
    end
end

